# Instruction: Complete ____ and add additional codes at your will
using ADCME
using PyCall
using LinearAlgebra
using PyPlot
using Random
using DelimitedFiles
Random.seed!(233)

"""
u - temperature (the state variable)
f - source term 
kappa - diffusivity coefficient 
dt - time step 
dx - space step 
m, n - #intervals for x and y directions
see README.md for detailed explaination. 
"""
function heat_equation(u, f, kappa, dt, dx, m, n)
    heat_equation_ = load_op_and_grad("./build/libHeatEquation", "heat_equation")
    u, f, kappa, dt, dx, m, n = convert_to_tensor([u,f,kappa,dt,dx,m,n], [Float64,Float64,Float64,Float64,Float64,Int64,Int64])
    heat_equation_(u, f, kappa, dt, dx, m, n)
end

# simulation parameters 
m = 50
n = 50
NT = 50
h = 1 / m
dt = 1 / NT 

x = zeros((m + 1) * (n + 1))
y = zeros((m + 1) * (n + 1))
for i = 1:m + 1
    for j = 1:n + 1
        idx = (j - 1) * (m + 1) + i 
        x[idx] = (i - 1) * h 
        y[idx] = (j - 1) * h 
    end
end

F = zeros(NT + 1, (m + 1) * (n + 1))


a = Variable(1.0)
b = Variable(1.0)
c = Variable(1.0)
κ = a + b * x + c * y
for i = 1:NT + 1
    t = (i - 1) * dt 
    F[i,:] = dt * @. (exp(-t) * exp(-50 * ((x - 0.5)^2 + (y - 0.5)^2)))
end

########################### Simulation Loop ########################### 
function condition(i, u_arr)
    i <= NT + 1
end

function body(i, u_arr)
    u = read(u_arr, i - 1) # temperature vector at last step 
    u_next = heat_equation(u, F[i], κ, dt, h, m, n)
    i + 1, write(u_arr, i, u_next)
end

u_arr = TensorArray(NT + 1)
u_arr = write(u_arr, 1, zeros((m + 1) * (n + 1)))
F = constant(F) # Must be converted to Tensor, so that you can call F[i] where i is a tensor 
i = constant(2, dtype = Int32)
_, u = while_loop(condition, body, [i, u_arr])
u = set_shape(stack(u), (NT + 1, (m + 1) * (n + 1))) # Reshape TensorArray to a usual tensor 

########################### Simulation Ends ############################ 

idx1 = (11 - 1) * (m + 1) + 11 # for u1
idx2 = (41 - 1) * (m + 1) + 41 # for u2
u_pred = u[:, [idx1;idx2]]
u_obs = readdlm("data.txt")
loss = sum((u_pred - u_obs)^2) * 1e20

sess = Session(); init(sess)

BFGS!(sess, loss)

println("Backward error on u")
u_pred_val = run(sess, u_pred)
@show norm(u_pred_val - u_obs)

@show run(sess, [a, b, c])